import "./styles.css";
import Header from "./Header.jsx";
import Fotter from "./Fotter.jsx";
import Food from "./Food.jsx";

export default function App() {
  return (
    <>
      <Header />
      <Food />
      <Fotter />
      <Food />
      <Food />
    </>
  );
}
