function Fotter() {
  return (
    <footer>
      <p>&copy; {new Date().getFullYear()} our Website is Legal</p>
    </footer>
  );
}

export default Fotter;
